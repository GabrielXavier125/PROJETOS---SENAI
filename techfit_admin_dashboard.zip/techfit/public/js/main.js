// public/js/main.js

console.log('TechFit carregado');

document.addEventListener('DOMContentLoaded', () => {
    const alerta = document.querySelector('.alerta');
    if (alerta) {
        setTimeout(() => {
            alerta.classList.add('alerta-fechando');
            setTimeout(() => alerta.remove(), 400);
        }, 4000);
    }
});
