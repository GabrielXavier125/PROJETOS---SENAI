-- db.sql - Script de criação do banco de dados TechFit

CREATE DATABASE IF NOT EXISTS techfit CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE techfit;

CREATE TABLE alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    data_nascimento DATE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    endereco VARCHAR(150),
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('ativo','inativo') DEFAULT 'ativo'
);

CREATE TABLE modalidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(60) NOT NULL,
    descricao TEXT,
    nivel ENUM('iniciante','intermediario','avancado') DEFAULT 'iniciante'
);

CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_modalidade INT NOT NULL,
    nome VARCHAR(60) NOT NULL,
    dia_semana ENUM('segunda','terca','quarta','quinta','sexta','sabado') NOT NULL,
    horario TIME NOT NULL,
    capacidade INT NOT NULL,
    ativo TINYINT(1) DEFAULT 1,
    FOREIGN KEY (id_modalidade) REFERENCES modalidades(id)
);

CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno INT NOT NULL,
    id_turma INT NOT NULL,
    data_aula DATE NOT NULL,
    status ENUM('confirmado','cancelado','espera') DEFAULT 'confirmado',
    data_agendamento DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_aluno) REFERENCES alunos(id),
    FOREIGN KEY (id_turma) REFERENCES turmas(id)
);

CREATE TABLE acessos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno INT NOT NULL,
    data_hora_entrada DATETIME NOT NULL,
    data_hora_saida DATETIME,
    tipo_identificacao ENUM('qrcode','biometria','cartao') NOT NULL,
    dispositivo VARCHAR(60),
    FOREIGN KEY (id_aluno) REFERENCES alunos(id)
);

CREATE TABLE avaliacoes_fisicas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno INT NOT NULL,
    data_avaliacao DATE NOT NULL,
    peso DECIMAL(5,2),
    altura DECIMAL(4,2),
    percentual_gordura DECIMAL(5,2),
    massa_magra DECIMAL(5,2),
    observacoes TEXT,
    sugestao_treino TEXT,
    proxima_avaliacao DATE,
    FOREIGN KEY (id_aluno) REFERENCES alunos(id)
);

CREATE TABLE mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_remetente INT NOT NULL,
    tipo_remetente ENUM('aluno','instrutor','admin') NOT NULL,
    id_destinatario INT NOT NULL,
    assunto VARCHAR(100),
    conteudo TEXT NOT NULL,
    data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
    lida TINYINT(1) DEFAULT 0
);

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    perfil ENUM('admin','aluno','instrutor') DEFAULT 'aluno',
    ativo TINYINT(1) DEFAULT 1
);

-- Usuários de exemplo
-- Por simplicidade, as senhas estão em texto puro: '123456'
-- O AuthController possui um fallback didático que aceita esse formato,
-- além de funcionar com hashes gerados por password_hash.

INSERT INTO usuarios (nome, email, cpf, senha_hash, perfil, ativo)
VALUES ('Administrador TechFit', 'admin@techfit.com', '111.111.111-11', '123456', 'admin', 1);

INSERT INTO usuarios (nome, email, cpf, senha_hash, perfil, ativo)
VALUES ('Instrutor TechFit', 'instrutor@techfit.com', '222.222.222-22', '123456', 'instrutor', 1);

INSERT INTO usuarios (nome, email, cpf, senha_hash, perfil, ativo)
VALUES ('Aluno Teste', 'aluno@techfit.com', '333.333.333-33', '123456', 'aluno', 1);
