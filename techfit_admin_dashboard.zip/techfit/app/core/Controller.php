<?php
// app/core/Controller.php

class Controller {
    protected function render($view, $data = []) {
        extract($data);
        $viewFile = __DIR__ . '/../views/' . $view . '.php';

        include __DIR__ . '/../views/layout/header.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            echo '<p>View não encontrada: ' . htmlspecialchars($view) . '</p>';
        }
        include __DIR__ . '/../views/layout/footer.php';
    }
}
