<?php
// app/views/layout/header.php
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>TechFit - Sistema de Academia</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="topo">
    <div class="logo">TechFit</div>
    <nav>
        <a href="index.php">Início</a>

        <?php if (!empty($_SESSION['usuario_perfil']) && $_SESSION['usuario_perfil'] === 'admin'): ?>
            <a href="index.php?controller=Admin&action=index">Dashboard</a>
            <a href="index.php?controller=Usuario&action=index">Usuários</a>
        <?php endif; ?>

        <?php if (empty($_SESSION['usuario_nome'])): ?>
            <a href="index.php?controller=Auth&action=login">Login</a>
        <?php endif; ?>

        <?php if (!empty($_SESSION['usuario_nome'])): ?>
            <span class="usuario-logado">
                Olá, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?> (<?php echo htmlspecialchars($_SESSION['usuario_perfil']); ?>)
            </span>
            <a href="index.php?controller=Auth&action=logout" class="link-logout">Sair</a>
        <?php endif; ?>
    </nav>
</header>
<main class="conteudo">
