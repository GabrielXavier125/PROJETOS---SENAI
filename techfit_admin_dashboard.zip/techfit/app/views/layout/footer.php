<?php
// app/views/layout/footer.php
?>
</main>
<footer class="rodape">
    <p>&copy; <?php echo date('Y'); ?> TechFit - Sistema de Academia</p>
</footer>
<script src="js/main.js"></script>
</body>
</html>
