<?php
// app/views/usuario/listar.php
?>
<section>
    <div class="cabecalho-pagina">
        <h1>Usuários</h1>
        <a class="botao" href="index.php?controller=Usuario&action=create">+ Novo Usuário</a>
    </div>

    <form method="get" class="form-busca">
        <input type="hidden" name="controller" value="Usuario">
        <input type="hidden" name="action" value="index">

        <input type="text" name="busca" placeholder="Buscar por nome, e-mail, CPF ou perfil"
               value="<?php echo htmlspecialchars($busca ?? ''); ?>">

        <select name="perfil">
            <option value="">Todos os perfis</option>
            <option value="admin" <?php echo (isset($perfil) && $perfil === 'admin') ? 'selected' : ''; ?>>Admin</option>
            <option value="instrutor" <?php echo (isset($perfil) && $perfil === 'instrutor') ? 'selected' : ''; ?>>Instrutor</option>
            <option value="aluno" <?php echo (isset($perfil) && $perfil === 'aluno') ? 'selected' : ''; ?>>Aluno</option>
        </select>

        <select name="ativo">
            <option value="todos" <?php echo (!isset($ativo) || $ativo === 'todos') ? 'selected' : ''; ?>>Todos</option>
            <option value="1" <?php echo (isset($ativo) && (string)$ativo === '1') ? 'selected' : ''; ?>>Ativos</option>
            <option value="0" <?php echo (isset($ativo) && (string)$ativo === '0') ? 'selected' : ''; ?>>Inativos</option>
        </select>

        <button type="submit" class="botao botao-pequeno">Filtrar</button>

        <?php if (!empty($busca) || !empty($perfil) || (isset($ativo) && $ativo !== 'todos')): ?>
            <a href="index.php?controller=Usuario&action=index" class="botao botao-secundario botao-pequeno">Limpar</a>
        <?php endif; ?>
    </form>

    <?php if (!empty($msg)): ?>
        <div class="alerta <?php echo $type === 'success' ? 'alerta-sucesso' : 'alerta-erro'; ?>">
            <?php echo htmlspecialchars($msg); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($usuarios)): ?>
        <div class="tabela-container">
            <table class="tabela">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>CPF</th>
                        <th>Perfil</th>
                        <th>Status</th>
                        <th class="col-acoes">Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($usuario->getNome()); ?></td>
                        <td><?php echo htmlspecialchars($usuario->getEmail()); ?></td>
                        <td><?php echo htmlspecialchars($usuario->getCpf()); ?></td>
                        <td>
                            <span class="badge-perfil badge-perfil-<?php echo htmlspecialchars($usuario->getPerfil()); ?>">
                                <?php echo htmlspecialchars(ucfirst($usuario->getPerfil())); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge <?php echo $usuario->getAtivo() ? 'badge-ativo' : 'badge-inativo'; ?>">
                                <?php echo $usuario->getAtivo() ? 'Ativo' : 'Inativo'; ?>
                            </span>
                        </td>
                        <td class="col-acoes">
                            <a class="link-acao" href="index.php?controller=Usuario&action=edit&id=<?php echo $usuario->getId(); ?>">Editar</a>
                            <a class="link-acao link-perigo" href="index.php?controller=Usuario&action=delete&id=<?php echo $usuario->getId(); ?>"
                               onclick="return confirm('Deseja realmente excluir este usuário?');">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p>Nenhum usuário encontrado.</p>
    <?php endif; ?>
</section>
