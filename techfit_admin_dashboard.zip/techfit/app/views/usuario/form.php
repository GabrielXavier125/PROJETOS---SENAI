<?php
// app/views/usuario/form.php

$editando = isset($usuario);
?>
<section>
    <h1><?php echo $editando ? 'Editar Usuário' : 'Novo Usuário'; ?></h1>

    <form method="post">
        <label>Nome:
            <input type="text" name="nome" required value="<?php echo $editando ? htmlspecialchars($usuario->getNome()) : ''; ?>">
        </label>

        <label>E-mail:
            <input type="email" name="email" required value="<?php echo $editando ? htmlspecialchars($usuario->getEmail()) : ''; ?>">
        </label>

        <label>CPF:
            <input type="text" name="cpf" required placeholder="000.000.000-00" value="<?php echo $editando ? htmlspecialchars($usuario->getCpf()) : ''; ?>">
        </label>

        <label>Perfil de Acesso:
            <select name="perfil">
                <option value="admin" <?php echo $editando && $usuario->getPerfil() === 'admin' ? 'selected' : ''; ?>>Admin</option>
                <option value="instrutor" <?php echo $editando && $usuario->getPerfil() === 'instrutor' ? 'selected' : ''; ?>>Instrutor</option>
                <option value="aluno" <?php echo $editando && $usuario->getPerfil() === 'aluno' ? 'selected' : ''; ?>>Aluno</option>
            </select>
        </label>

        <label>
            <input type="checkbox" name="ativo" <?php echo !$editando || $usuario->getAtivo() ? 'checked' : ''; ?>>
            Usuário ativo
        </label>

        <label>Senha:
            <input type="password" name="senha" placeholder="<?php echo $editando ? 'Deixe em branco para manter a senha atual' : 'Defina uma senha'; ?>">
        </label>

        <button class="botao" type="submit">Salvar</button>
        <a class="botao botao-secundario" href="index.php?controller=Usuario&action=index">Voltar</a>
    </form>
</section>
