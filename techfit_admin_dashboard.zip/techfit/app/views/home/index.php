<?php
// app/views/home/index.php
?>
<section class="banner">
    <h1>Bem-vindo à TechFit</h1>
    <p>Modernize a gestão da sua academia com nosso sistema completo de agendamento, controle de acesso, avaliações físicas e comunicação com alunos.</p>
    <a class="botao" href="index.php?controller=Auth&action=login">Login TechFit</a>
</section>

<section class="cards">
    <div class="card">
        <h2>Agendamento Online</h2>
        <p>Organize turmas, horários e listas de espera.</p>
    </div>
    <div class="card">
        <h2>Controle de Acesso</h2>
        <p>Registre entradas e saídas dos alunos com segurança.</p>
    </div>
    <div class="card">
        <h2>Avaliação Física</h2>
        <p>Acompanhe a evolução física do aluno com gráficos e históricos.</p>
    </div>
</section>
