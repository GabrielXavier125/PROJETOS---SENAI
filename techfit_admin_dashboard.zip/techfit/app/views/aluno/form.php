<?php
// app/views/aluno/form.php

$editando = isset($aluno);
?>
<section>
    <h1><?php echo $editando ? 'Editar Aluno' : 'Novo Aluno'; ?></h1>

    <form method="post">
        <label>Nome:
            <input type="text" name="nome" required value="<?php echo $editando ? htmlspecialchars($aluno->getNome()) : ''; ?>">
        </label>

        <label>CPF:
            <input type="text" name="cpf" required value="<?php echo $editando ? htmlspecialchars($aluno->getCpf()) : ''; ?>">
        </label>

        <label>Data de Nascimento:
            <input type="date" name="data_nascimento" required value="<?php echo $editando ? htmlspecialchars($aluno->getDataNascimento()) : ''; ?>">
        </label>

        <label>E-mail:
            <input type="email" name="email" required value="<?php echo $editando ? htmlspecialchars($aluno->getEmail()) : ''; ?>">
        </label>

        <label>Telefone:
            <input type="text" name="telefone" value="<?php echo $editando ? htmlspecialchars($aluno->getTelefone()) : ''; ?>">
        </label>

        <label>Endereço:
            <input type="text" name="endereco" value="<?php echo $editando ? htmlspecialchars($aluno->getEndereco()) : ''; ?>">
        </label>

        <?php if ($editando): ?>
            <label>Status:
                <select name="status">
                    <option value="ativo" <?php echo $aluno->getStatus() === 'ativo' ? 'selected' : ''; ?>>Ativo</option>
                    <option value="inativo" <?php echo $aluno->getStatus() === 'inativo' ? 'selected' : ''; ?>>Inativo</option>
                </select>
            </label>
        <?php endif; ?>

        <button class="botao" type="submit">Salvar</button>
        <a class="botao botao-secundario" href="index.php?controller=Aluno&action=index">Voltar</a>
    </form>
</section>
