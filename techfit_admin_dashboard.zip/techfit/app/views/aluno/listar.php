<?php
// app/views/aluno/listar.php

$msg  = $_GET['msg']  ?? '';
$type = $_GET['type'] ?? '';
?>
<section>
    <div class="cabecalho-pagina">
        <h1>Alunos</h1>
        <a class="botao" href="index.php?controller=Aluno&action=create">+ Novo Aluno</a>
    </div>

    <form method="get" class="form-busca">
        <input type="hidden" name="controller" value="Aluno">
        <input type="hidden" name="action" value="index">
        <input type="text" name="busca" placeholder="Buscar por nome, CPF ou e-mail" value="<?php echo htmlspecialchars($busca ?? ''); ?>">
        <button type="submit" class="botao botao-pequeno">Buscar</button>
        <?php if (!empty($busca)): ?>
            <a href="index.php?controller=Aluno&action=index" class="botao botao-secundario botao-pequeno">Limpar</a>
        <?php endif; ?>
    </form>

    <?php if (!empty($msg)): ?>
        <div class="alerta <?php echo $type === 'success' ? 'alerta-sucesso' : 'alerta-erro'; ?>">
            <?php echo htmlspecialchars($msg); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($alunos)): ?>
        <div class="tabela-container">
            <table class="tabela">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>E-mail</th>
                        <th>Telefone</th>
                        <th>Status</th>
                        <th class="col-acoes">Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($alunos as $aluno): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($aluno->getNome()); ?></td>
                        <td><?php echo htmlspecialchars($aluno->getCpf()); ?></td>
                        <td><?php echo htmlspecialchars($aluno->getEmail()); ?></td>
                        <td><?php echo htmlspecialchars($aluno->getTelefone()); ?></td>
                        <td>
                            <span class="badge <?php echo $aluno->getStatus() === 'ativo' ? 'badge-ativo' : 'badge-inativo'; ?>">
                                <?php echo htmlspecialchars($aluno->getStatus()); ?>
                            </span>
                        </td>
                        <td class="col-acoes">
                            <a class="link-acao" href="index.php?controller=Aluno&action=edit&id=<?php echo $aluno->getId(); ?>">Editar</a>
                            <a class="link-acao link-perigo" href="index.php?controller=Aluno&action=delete&id=<?php echo $aluno->getId(); ?>"
                               onclick="return confirm('Deseja realmente excluir este aluno?');">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p>Nenhum aluno encontrado.</p>
    <?php endif; ?>
</section>
