<?php
// app/views/auth/login.php
?>
<section class="login-container">
    <div class="login-card">
        <h1>Login TechFit</h1>
        <p class="login-subtitulo">Acesse o painel da academia com seu e-mail e senha.</p>

        <?php if (!empty($erro)): ?>
            <div class="alerta alerta-erro">
                <?php echo htmlspecialchars($erro); ?>
            </div>
        <?php endif; ?>

        <form method="post" class="form-login">
            <label>E-mail:
                <input type="email" name="email" required placeholder="seuemail@techfit.com">
            </label>

            <label>Senha:
                <input type="password" name="senha" required placeholder="********">
            </label>

            <button type="submit" class="botao botao-login">Entrar</button>
        </form>

        <p class="login-info">
            * Neste protótipo, os usuários são cadastrados pela administração no banco de dados.
        </p>
    </div>
</section>
