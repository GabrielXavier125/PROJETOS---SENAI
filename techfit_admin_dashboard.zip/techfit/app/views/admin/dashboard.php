<?php
// app/views/admin/dashboard.php
?>
<section>
    <h1>Painel Administrativo - TechFit</h1>
    <p class="texto-intro-dashboard">
        Visão geral dos principais indicadores da academia.
    </p>

    <div class="dashboard-grid">
        <div class="card-kpi destaque">
            <h2>Total de Usuários</h2>
            <p class="kpi-numero"><?php echo $totalUsuarios; ?></p>
            <p class="kpi-legenda">Todos os perfis cadastrados no sistema</p>
        </div>

        <div class="card-kpi">
            <h3>Admins</h3>
            <p class="kpi-numero"><?php echo $totalAdmins; ?></p>
            <p class="kpi-legenda">Usuários com acesso total ao painel</p>
        </div>

        <div class="card-kpi">
            <h3>Instrutores</h3>
            <p class="kpi-numero"><?php echo $totalInstrutores; ?></p>
            <p class="kpi-legenda">Responsáveis por avaliações e treinos</p>
        </div>

        <div class="card-kpi">
            <h3>Alunos (usuários)</h3>
            <p class="kpi-numero"><?php echo $totalAlunosPerfil; ?></p>
            <p class="kpi-legenda">Logins de alunos no sistema</p>
        </div>

        <div class="card-kpi">
            <h3>Usuários Ativos</h3>
            <p class="kpi-numero"><?php echo $totalAtivos; ?></p>
            <p class="kpi-legenda">Com acesso liberado</p>
        </div>

        <div class="card-kpi">
            <h3>Usuários Inativos</h3>
            <p class="kpi-numero"><?php echo $totalInativos; ?></p>
            <p class="kpi-legenda">Acesso bloqueado / desativado</p>
        </div>

        <div class="card-kpi">
            <h3>Alunos cadastrados</h3>
            <p class="kpi-numero"><?php echo $totalAlunosCadastro; ?></p>
            <p class="kpi-legenda">Registros na tabela de alunos</p>
        </div>

        <div class="card-kpi">
            <h3>Modalidades</h3>
            <p class="kpi-numero"><?php echo $totalModalidades; ?></p>
            <p class="kpi-legenda">Tipos de aulas disponíveis</p>
        </div>

        <div class="card-kpi">
            <h3>Turmas</h3>
            <p class="kpi-numero"><?php echo $totalTurmas; ?></p>
            <p class="kpi-legenda">Turmas criadas para as modalidades</p>
        </div>

        <div class="card-kpi">
            <h3>Agendamentos</h3>
            <p class="kpi-numero"><?php echo $totalAgendamentos; ?></p>
            <p class="kpi-legenda">Reservas realizadas pelos alunos</p>
        </div>
    </div>

    <div class="dashboard-links">
        <a class="botao" href="index.php?controller=Usuario&action=index">Gerenciar Usuários</a>
        <a class="botao botao-secundario" href="index.php?controller=Aluno&action=index">Gerenciar Alunos</a>
    </div>
</section>
