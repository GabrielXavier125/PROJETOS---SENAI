<?php
// app/controllers/AdminController.php

class AdminController extends Controller
{
    private $pdo;

    public function __construct()
    {
        if (empty($_SESSION['usuario_perfil']) || $_SESSION['usuario_perfil'] !== 'admin') {
            header('Location: index.php?controller=Auth&action=login');
            exit;
        }

        $this->pdo = Database::getInstance();
    }

    public function index()
    {
        // Total de usuários
        $totalUsuarios = $this->simpleCount("SELECT COUNT(*) FROM usuarios");

        // Usuários por perfil
        $totalAdmins      = $this->simpleCount("SELECT COUNT(*) FROM usuarios WHERE perfil = 'admin'");
        $totalInstrutores = $this->simpleCount("SELECT COUNT(*) FROM usuarios WHERE perfil = 'instrutor'");
        $totalAlunosPerfil = $this->simpleCount("SELECT COUNT(*) FROM usuarios WHERE perfil = 'aluno'");

        // Usuários ativos / inativos
        $totalAtivos   = $this->simpleCount("SELECT COUNT(*) FROM usuarios WHERE ativo = 1");
        $totalInativos = $this->simpleCount("SELECT COUNT(*) FROM usuarios WHERE ativo = 0");

        // Total de alunos cadastrados na tabela alunos (cadastro acadêmico)
        $totalAlunosCadastro = $this->simpleCount("SELECT COUNT(*) FROM alunos");

        // Futuro: quantidade de turmas, modalidades, agendamentos, etc.
        $totalModalidades = $this->simpleCount("SELECT COUNT(*) FROM modalidades");
        $totalTurmas      = $this->simpleCount("SELECT COUNT(*) FROM turmas");
        $totalAgendamentos = $this->simpleCount("SELECT COUNT(*) FROM agendamentos");

        $this->render('admin/dashboard', [
            'totalUsuarios'       => $totalUsuarios,
            'totalAdmins'         => $totalAdmins,
            'totalInstrutores'    => $totalInstrutores,
            'totalAlunosPerfil'   => $totalAlunosPerfil,
            'totalAtivos'         => $totalAtivos,
            'totalInativos'       => $totalInativos,
            'totalAlunosCadastro' => $totalAlunosCadastro,
            'totalModalidades'    => $totalModalidades,
            'totalTurmas'         => $totalTurmas,
            'totalAgendamentos'   => $totalAgendamentos,
        ]);
    }

    private function simpleCount($sql)
    {
        try {
            $stmt = $this->pdo->query($sql);
            return (int) $stmt->fetchColumn();
        } catch (Exception $e) {
            return 0;
        }
    }
}
