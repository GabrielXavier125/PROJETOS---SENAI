<?php
// app/controllers/UsuarioController.php

class UsuarioController extends Controller {

    private $usuarioDAO;

    public function __construct() {
        if (empty($_SESSION['usuario_perfil']) || $_SESSION['usuario_perfil'] !== 'admin') {
            header('Location: index.php?controller=Auth&action=login');
            exit;
        }

        $pdo = Database::getInstance();
        $this->usuarioDAO = new UsuarioDAO($pdo);
    }

    public function index() {
        $busca  = $_GET['busca']  ?? '';
        $perfil = $_GET['perfil'] ?? '';
        $ativo  = $_GET['ativo']  ?? 'todos';

        $usuarios = $this->usuarioDAO->filter($busca, $perfil, $ativo);

        $msg  = $_GET['msg']  ?? '';
        $type = $_GET['type'] ?? '';

        $this->render('usuario/listar', [
            'usuarios' => $usuarios,
            'busca'    => $busca,
            'perfil'   => $perfil,
            'ativo'    => $ativo,
            'msg'      => $msg,
            'type'     => $type
        ]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $usuario = new Usuario();
            $usuario->setNome($_POST['nome'] ?? '');
            $usuario->setEmail($_POST['email'] ?? '');
            $usuario->setCpf($_POST['cpf'] ?? '');
            $usuario->setPerfil($_POST['perfil'] ?? 'aluno');
            $usuario->setAtivo(isset($_POST['ativo']) ? 1 : 0);

            $senha = $_POST['senha'] ?? '';
            if ($senha !== '') {
                // Em produção use sempre hash:
                // $hash = password_hash($senha, PASSWORD_DEFAULT);
                $hash = $senha; // didático
            } else {
                $hash = '';
            }
            $usuario->setSenhaHash($hash);

            $ok = $this->usuarioDAO->create($usuario);
            $msg = $ok ? 'Usuário criado com sucesso!' : 'Erro ao criar usuário.';
            $type = $ok ? 'success' : 'error';

            header('Location: index.php?controller=Usuario&action=index&msg=' . urlencode($msg) . '&type=' . $type);
            exit;
        }

        $this->render('usuario/form');
    }

    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: index.php?controller=Usuario&action=index');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $usuario = $this->usuarioDAO->findById($id);
            if ($usuario) {
                $usuario->setNome($_POST['nome'] ?? '');
                $usuario->setEmail($_POST['email'] ?? '');
                $usuario->setCpf($_POST['cpf'] ?? '');
                $usuario->setPerfil($_POST['perfil'] ?? 'aluno');
                $usuario->setAtivo(isset($_POST['ativo']) ? 1 : 0);

                $senha = $_POST['senha'] ?? '';
                if ($senha !== '') {
                    // $hash = password_hash($senha, PASSWORD_DEFAULT);
                    $hash = $senha; // didático
                    $usuario->setSenhaHash($hash);
                }

                $ok = $this->usuarioDAO->update($usuario);
                $msg = $ok ? 'Usuário atualizado com sucesso!' : 'Erro ao atualizar usuário.';
                $type = $ok ? 'success' : 'error';
            } else {
                $msg = 'Usuário não encontrado.';
                $type = 'error';
            }

            header('Location: index.php?controller=Usuario&action=index&msg=' . urlencode($msg) . '&type=' . $type);
            exit;
        }

        $usuario = $this->usuarioDAO->findById($id);
        $this->render('usuario/form', ['usuario' => $usuario]);
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $ok = $this->usuarioDAO->delete($id);
            $msg = $ok ? 'Usuário excluído com sucesso!' : 'Erro ao excluir usuário.';
            $type = $ok ? 'success' : 'error';
        } else {
            $msg = 'Usuário não informado.';
            $type = 'error';
        }

        header('Location: index.php?controller=Usuario&action=index&msg=' . urlencode($msg) . '&type=' . $type);
        exit;
    }
}
