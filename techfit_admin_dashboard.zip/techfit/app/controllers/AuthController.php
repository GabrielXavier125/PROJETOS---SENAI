<?php
// app/controllers/AuthController.php

class AuthController extends Controller {

    private $usuarioDAO;

    public function __construct() {
        $pdo = Database::getInstance();
        $this->usuarioDAO = new UsuarioDAO($pdo);
    }

    public function login() {
        $erro = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $senha = $_POST['senha'] ?? '';

            if ($email === '' || $senha === '') {
                $erro = 'Informe e-mail e senha.';
            } else {
                $usuario = $this->usuarioDAO->findByEmail($email);
                if ($usuario) {
                    $hash = $usuario->getSenhaHash();

                    // Preferencialmente use password_hash/password_verify com hash armazenado.
                    $ok = false;
                    if (!empty($hash)) {
                        if (password_verify($senha, $hash)) {
                            $ok = true;
                        } elseif ($hash === $senha) {
                            // fallback didático: permite senha em texto puro para testes
                            $ok = true;
                        }
                    }

                    if ($ok) {
                        $_SESSION['usuario_id'] = $usuario->getId();
                        $_SESSION['usuario_nome'] = $usuario->getNome();
                        $_SESSION['usuario_perfil'] = $usuario->getPerfil();

                        if ($usuario->getPerfil() === 'admin') {
                        header('Location: index.php?controller=Admin&action=index');
                    } elseif ($usuario->getPerfil() === 'instrutor') {
                        header('Location: index.php'); // futuramente: dashboard instrutor
                    } else {
                        header('Location: index.php'); // futuramente: área do aluno
                    }
                        exit;
                    } else {
                        $erro = 'Credenciais inválidas.';
                    }
                } else {
                    $erro = 'Usuário não encontrado ou inativo.';
                }
            }
        }

        $this->render('auth/login', ['erro' => $erro]);
    }

    public function logout() {
        session_unset();
        session_destroy();
        header('Location: index.php');
        exit;
    }
}
