<?php
// app/controllers/HomeController.php

class HomeController extends Controller {
    public function index() {
        $this->render('home/index');
    }
}
