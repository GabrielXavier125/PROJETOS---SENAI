<?php
// app/controllers/AlunoController.php

class AlunoController extends Controller {

    private $alunoDAO;

    public function __construct() {
        // Garante que apenas admin tem acesso a este controller
        if (empty($_SESSION['usuario_perfil']) || $_SESSION['usuario_perfil'] !== 'admin') {
            header('Location: index.php?controller=Auth&action=login');
            exit;
        }

        $pdo = Database::getInstance();
        $this->alunoDAO = new AlunoDAO($pdo);
    }

    public function index() {
        $busca = $_GET['busca'] ?? '';
        if (!empty($busca)) {
            $alunos = $this->alunoDAO->search($busca);
        } else {
            $alunos = $this->alunoDAO->findAll();
        }
        $this->render('aluno/listar', [
            'alunos' => $alunos,
            'busca'  => $busca
        ]);
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $aluno = new Aluno();
            $aluno->setNome($_POST['nome'] ?? '');
            $aluno->setCpf($_POST['cpf'] ?? '');
            $aluno->setDataNascimento($_POST['data_nascimento'] ?? '');
            $aluno->setEmail($_POST['email'] ?? '');
            $aluno->setTelefone($_POST['telefone'] ?? '');
            $aluno->setEndereco($_POST['endereco'] ?? '');
            $aluno->setStatus('ativo');

            $ok = $this->alunoDAO->create($aluno);
            $msg = $ok ? 'Aluno cadastrado com sucesso!' : 'Erro ao cadastrar aluno.';
            $type = $ok ? 'success' : 'error';

            header('Location: index.php?controller=Aluno&action=index&msg=' . urlencode($msg) . '&type=' . $type);
            exit;
        }

        $this->render('aluno/form');
    }

    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: index.php?controller=Aluno&action=index');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $aluno = $this->alunoDAO->findById($id);
            if ($aluno) {
                $aluno->setNome($_POST['nome'] ?? '');
                $aluno->setCpf($_POST['cpf'] ?? '');
                $aluno->setDataNascimento($_POST['data_nascimento'] ?? '');
                $aluno->setEmail($_POST['email'] ?? '');
                $aluno->setTelefone($_POST['telefone'] ?? '');
                $aluno->setEndereco($_POST['endereco'] ?? '');
                $aluno->setStatus($_POST['status'] ?? 'ativo');

                $ok = $this->alunoDAO->update($aluno);
                $msg = $ok ? 'Aluno atualizado com sucesso!' : 'Erro ao atualizar aluno.';
                $type = $ok ? 'success' : 'error';
            } else {
                $msg = 'Aluno não encontrado.';
                $type = 'error';
            }

            header('Location: index.php?controller=Aluno&action=index&msg=' . urlencode($msg) . '&type=' . $type);
            exit;
        }

        $aluno = $this->alunoDAO->findById($id);
        $this->render('aluno/form', ['aluno' => $aluno]);
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $ok = $this->alunoDAO->delete($id);
            $msg = $ok ? 'Aluno excluído com sucesso!' : 'Erro ao excluir aluno.';
            $type = $ok ? 'success' : 'error';
        } else {
            $msg = 'Aluno não informado.';
            $type = 'error';
        }
        header('Location: index.php?controller=Aluno&action=index&msg=' . urlencode($msg) . '&type=' . $type);
        exit;
    }
}
