<?php
// app/models/dao/UsuarioDAO.php

class UsuarioDAO {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function findByEmail($email) {
        $sql = "SELECT * FROM usuarios WHERE email = :email AND ativo = 1 LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':email', $email);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            return $this->mapUsuario($data);
        }

        return null;
    }

    public function findById($id) {
        $sql = "SELECT * FROM usuarios WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            return $this->mapUsuario($data);
        }

        return null;
    }

    public function findAll() {
        $sql = "SELECT * FROM usuarios ORDER BY nome";
        $stmt = $this->pdo->query($sql);
        $result = [];

        while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = $this->mapUsuario($data);
        }

        return $result;
    }

    /**
     * Lista usuários aplicando filtros opcionais de busca, perfil e status (ativo/inativo).
     */
    public function filter($termo = '', $perfil = '', $ativo = '') {
        $sql = "SELECT * FROM usuarios WHERE 1=1";
        $params = [];

        if ($termo !== '') {
            $sql .= " AND (nome LIKE :termo OR email LIKE :termo OR cpf LIKE :termo OR perfil LIKE :termo)";
            $params[':termo'] = '%' . $termo . '%';
        }

        if ($perfil !== '' && in_array($perfil, ['admin','instrutor','aluno'], true)) {
            $sql .= " AND perfil = :perfil";
            $params[':perfil'] = $perfil;
        }

        if ($ativo !== '' && $ativo !== 'todos') {
            if ($ativo === '1' || $ativo === 1 || $ativo === '0' || $ativo === 0):
                $sql .= " AND ativo = :ativo";
                $params[':ativo'] = (int)$ativo;
            endif;
        }

        $sql .= " ORDER BY nome";

        $stmt = $this->pdo->prepare($sql);

        foreach ($params as $key => $value) {
            if ($key === ':ativo') {
                $stmt->bindValue($key, $value, PDO::PARAM_INT);
            } else {
                $stmt->bindValue($key, $value);
            }
        }

        $stmt->execute();

        $result = [];
        while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = $this->mapUsuario($data);
        }
        return $result;
    }

    public function create(Usuario $usuario) {
        $sql = "INSERT INTO usuarios (nome, email, cpf, senha_hash, perfil, ativo)
                VALUES (:nome, :email, :cpf, :senha_hash, :perfil, :ativo)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':cpf', $usuario->getCpf());
        $stmt->bindValue(':senha_hash', $usuario->getSenhaHash());
        $stmt->bindValue(':perfil', $usuario->getPerfil());
        $stmt->bindValue(':ativo', $usuario->getAtivo(), PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function update(Usuario $usuario) {
        $sql = "UPDATE usuarios
                   SET nome = :nome,
                       email = :email,
                       cpf = :cpf,
                       senha_hash = :senha_hash,
                       perfil = :perfil,
                       ativo = :ativo
                 WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome', $usuario->getNome());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':cpf', $usuario->getCpf());
        $stmt->bindValue(':senha_hash', $usuario->getSenhaHash());
        $stmt->bindValue(':perfil', $usuario->getPerfil());
        $stmt->bindValue(':ativo', $usuario->getAtivo(), PDO::PARAM_INT);
        $stmt->bindValue(':id', $usuario->getId(), PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function delete($id) {
        $sql = "DELETE FROM usuarios WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    private function mapUsuario(array $data) {
        $usuario = new Usuario();
        $usuario->setId($data['id']);
        $usuario->setNome($data['nome']);
        $usuario->setEmail($data['email']);
        $usuario->setCpf($data['cpf']);
        $usuario->setSenhaHash($data['senha_hash']);
        $usuario->setPerfil($data['perfil']);
        $usuario->setAtivo($data['ativo']);
        return $usuario;
    }
}
