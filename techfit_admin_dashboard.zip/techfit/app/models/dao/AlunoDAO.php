<?php
// app/models/dao/AlunoDAO.php

class AlunoDAO {
    private $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function create(Aluno $aluno) {
        $sql = "INSERT INTO alunos (nome, cpf, data_nascimento, email, telefone, endereco, status)
                VALUES (:nome, :cpf, :data_nascimento, :email, :telefone, :endereco, 'ativo')";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome', $aluno->getNome());
        $stmt->bindValue(':cpf', $aluno->getCpf());
        $stmt->bindValue(':data_nascimento', $aluno->getDataNascimento());
        $stmt->bindValue(':email', $aluno->getEmail());
        $stmt->bindValue(':telefone', $aluno->getTelefone());
        $stmt->bindValue(':endereco', $aluno->getEndereco());
        return $stmt->execute();
    }

    public function update(Aluno $aluno) {
        $sql = "UPDATE alunos SET nome = :nome, cpf = :cpf, data_nascimento = :data_nascimento,
                email = :email, telefone = :telefone, endereco = :endereco, status = :status
                WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome', $aluno->getNome());
        $stmt->bindValue(':cpf', $aluno->getCpf());
        $stmt->bindValue(':data_nascimento', $aluno->getDataNascimento());
        $stmt->bindValue(':email', $aluno->getEmail());
        $stmt->bindValue(':telefone', $aluno->getTelefone());
        $stmt->bindValue(':endereco', $aluno->getEndereco());
        $stmt->bindValue(':status', $aluno->getStatus());
        $stmt->bindValue(':id', $aluno->getId(), PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function delete($id) {
        $sql = "DELETE FROM alunos WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function findById($id) {
        $sql = "SELECT * FROM alunos WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            $aluno = new Aluno();
            $aluno->setId($data['id']);
            $aluno->setNome($data['nome']);
            $aluno->setCpf($data['cpf']);
            $aluno->setDataNascimento($data['data_nascimento']);
            $aluno->setEmail($data['email']);
            $aluno->setTelefone($data['telefone']);
            $aluno->setEndereco($data['endereco']);
            $aluno->setStatus($data['status']);
            return $aluno;
        }

        return null;
    }

    public function findAll() {
        $sql = "SELECT * FROM alunos ORDER BY nome";
        $stmt = $this->pdo->query($sql);
        $result = [];

        while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $aluno = new Aluno();
            $aluno->setId($data['id']);
            $aluno->setNome($data['nome']);
            $aluno->setCpf($data['cpf']);
            $aluno->setDataNascimento($data['data_nascimento']);
            $aluno->setEmail($data['email']);
            $aluno->setTelefone($data['telefone']);
            $aluno->setEndereco($data['endereco']);
            $aluno->setStatus($data['status']);
            $result[] = $aluno;
        }

        return $result;
    }

    public function search($termo) {
        $sql = "SELECT * FROM alunos 
                WHERE nome LIKE :termo
                   OR email LIKE :termo
                   OR cpf LIKE :termo
                ORDER BY nome";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':termo', '%' . $termo . '%');
        $stmt->execute();

        $result = [];
        while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $aluno = new Aluno();
            $aluno->setId($data['id']);
            $aluno->setNome($data['nome']);
            $aluno->setCpf($data['cpf']);
            $aluno->setDataNascimento($data['data_nascimento']);
            $aluno->setEmail($data['email']);
            $aluno->setTelefone($data['telefone']);
            $aluno->setEndereco($data['endereco']);
            $aluno->setStatus($data['status']);
            $result[] = $aluno;
        }
        return $result;
    }
}
