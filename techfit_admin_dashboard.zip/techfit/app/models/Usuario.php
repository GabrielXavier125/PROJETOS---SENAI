<?php
// app/models/Usuario.php

class Usuario {
    private $id;
    private $nome;
    private $email;
    private $cpf;
    private $senha_hash;
    private $perfil;
    private $ativo;

    public function getId() {
        return $this->id;
    }
    public function setId($id) {
        $this->id = $id;
    }

    public function getNome() {
        return $this->nome;
    }
    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function getEmail() {
        return $this->email;
    }
    public function setEmail($email) {
        $this->email = $email;
    }

    public function getCpf() {
        return $this->cpf;
    }
    public function setCpf($cpf) {
        $this->cpf = $cpf;
    }

    public function getSenhaHash() {
        return $this->senha_hash;
    }
    public function setSenhaHash($senha_hash) {
        $this->senha_hash = $senha_hash;
    }

    public function getPerfil() {
        return $this->perfil;
    }
    public function setPerfil($perfil) {
        $this->perfil = $perfil;
    }

    public function getAtivo() {
        return $this->ativo;
    }
    public function setAtivo($ativo) {
        $this->ativo = $ativo;
    }
}
