<?php
// config/config.php

define('DB_HOST', 'localhost');
define('DB_NAME', 'techfit');
define('DB_USER', 'root');
define('DB_PASS', 'senaisp');

// Base URL do sistema (ajuste conforme seu ambiente)
define('BASE_URL', 'http://localhost/techfit/public');
